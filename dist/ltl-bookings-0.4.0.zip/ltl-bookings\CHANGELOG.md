# LazyBookings Changelog

## 0.4.0 — Release Candidate
- Release freeze: synced plugin and DB version to 0.4.0
- Added `LTLB_VERSION` constant and automatic DB version update via Migrator
- Stabilized admin pages and `[lazy_book]` shortcode for RC
- Misc: minor polish ahead of final release
