<?php
if ( ! defined('ABSPATH') ) exit;

class LTLB_Admin_CalendarPage {
	public function render(): void {
		if ( ! current_user_can('manage_options') ) {
			wp_die( esc_html__('You do not have permission to view this page.', 'ltl-bookings') );
		}

		?>
		<div class="wrap ltlb-admin">
			<?php if ( class_exists('LTLB_Admin_Header') ) { LTLB_Admin_Header::render('ltlb_calendar'); } ?>
			<h1 class="wp-heading-inline"><?php echo esc_html__('Calendar', 'ltl-bookings'); ?></h1>
			<hr class="wp-header-end">

			<div class="ltlb-card">
				<div id="ltlb-admin-calendar" style="min-height: 700px;"></div>
				<div id="ltlb-admin-calendar-details" class="ltlb-calendar-details" hidden></div>
			</div>
		</div>
		<?php
	}
}
