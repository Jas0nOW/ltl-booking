<?php
if ( ! defined('ABSPATH') ) exit;

class LTLB_Activator {

    public static function activate(): void {
        // Tabellen anlegen
        LTLB_DB_Migrator::migrate();

        // Default-Options (nur anlegen, wenn nicht vorhanden)
        add_option('lazy_settings', [
            'timezone' => 'Europe/Berlin',
            // Production defaults
            'logging_enabled' => 0,
            'log_level' => 'error',
            // Reserved flags for future privacy/rate limiting/email tests
            'rate_limit_enabled' => 0,
            'rate_limit_per_minute' => 60,
            'delete_data_on_uninstall' => 0,
			// Retention defaults (0 = disabled)
			'retention_delete_canceled_days' => 0,
			'retention_anonymize_after_days' => 0,
        ]);

        add_option('lazy_design', [
            // Colors
            'background' => '#FDFCF8',
            'text'       => '#3D3D3D',
            'primary'    => '#A67B5B',
            'primary_hover' => '#8DA399',
            'secondary' => '#A67B5B',
            'secondary_hover' => '#A67B5B',
            'accent'     => '#8DA399',
            'border_color' => '#cccccc',
            'panel_background' => 'transparent',
            'button_text' => '#ffffff',

            // Numeric tokens
            'border_width' => 1,
            'border_radius' => 4,
            'box_shadow_blur' => 4,
            'box_shadow_spread' => 0,
            'transition_duration' => 200,

            // Feature toggles
            'use_gradient' => 0,
            'enable_animations' => 1,
            'auto_button_text' => 1,
            'shadow_container' => 1,
            'shadow_button' => 1,
            'shadow_input' => 0,
            'shadow_card' => 1,

            // Custom CSS
            'custom_css' => '',
        ]);

		// Schedule retention cleanup (daily)
		if ( function_exists( 'wp_next_scheduled' ) && function_exists( 'wp_schedule_event' ) ) {
			if ( ! wp_next_scheduled( 'ltlb_retention_cleanup' ) ) {
				wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ltlb_retention_cleanup' );
			}
		}
    }
}