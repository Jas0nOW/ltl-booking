# LazyBookings Design Guide

Die kanonische Design-Dokumentation ist in:

- `docs/DESIGN_GUIDE.md`

Hintergrund:
- In LazyBookings existieren mehr Design-Tokens als nur vier Farben (z.B. Hover-Farben, Border/Radius, Shadows, Animationen, optionales Custom CSS).
- Diese Tokens werden auf `.ltlb-booking` (Frontend) sowie in der Admin-Preview verwendet.
